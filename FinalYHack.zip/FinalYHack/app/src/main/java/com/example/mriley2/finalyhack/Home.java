package com.example.mriley2.finalyhack;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Created by TMBL on 12/2/17.
 */

public class Home extends Activity {
    int request_Code=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void gotoCourse (View view){
        Intent intent = new Intent(getApplicationContext(), ListC.class);
        startActivityForResult(intent, request_Code);
    }
}

