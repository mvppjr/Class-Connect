package com.example.mriley2.finalyhack;

import java.util.List;

/**
 * Created by TMBL on 12/2/17.
 */

public class Course {
    private int id;
    private String title;
    private String professor;
    private List<Student> StuList;

    //Constructor
    public Course(String title0, String professor0){
        title = title0;
        professor = professor0;
    }

    //Returns the id of the Course
    public int getID(){
        return id;
    }

    //Sets the id of the Course
    public void setID(int id0){
        id = id0;
    }

    //Returns the title of the Course
    public String getTitle(){
        return title;
    }

    //Sets the title of the Course
    public void setTitle(String title0){
        title = title0;
    }

    //Returns the author of the Course
    public String getProfessor(){
        return professor;
    }

    //Sets the author of the Course
    public void setProfessor(String professor0){
        professor = professor0;
    }

    public void addStudent(Student student0){
        StuList.add(student0);
    }
}
