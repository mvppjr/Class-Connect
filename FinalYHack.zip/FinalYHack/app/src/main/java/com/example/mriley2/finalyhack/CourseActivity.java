package com.example.mriley2.finalyhack;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by TMBL on 12/2/17.
 */

public class CourseActivity extends Activity{
    String title;
    String author;
    CourseSQLHelper tdb;
    Course course;

    //Called when the first time this activity starts.
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course); //set up the layout

        //get the database
        tdb = new CourseSQLHelper(getApplicationContext());
        tdb.getWritableDatabase();

        // get the id of the selected book
        Intent intent = getIntent();
        int ID = intent.getIntExtra("id",0);

        //Search for the book to get the title and the book
        course = tdb.searchCourse(ID);
        title = course.getTitle();
        author = course.getProfessor();

        //Set up the acticity views for user interface
        TextView textView = (TextView)findViewById(R.id.textView5);
        textView.setText("Course: " + title);

        TextView textView2 = (TextView)findViewById(R.id.textView6);
        textView2.setText("Professor: " + author);

        EditText editText = (EditText)findViewById(R.id.editText);
        editText.setText(title);

        EditText editText2 = (EditText)findViewById(R.id.editText);
        editText2.setText(author);
    }

    //Called when the "UPDATE BOOK" Button is clicked
    public void updateData (View view) {

        //Get the information from the EditText
        EditText editText = (EditText)findViewById(R.id.editText);
        String inputTitle = editText.getText().toString();

        EditText editText2 = (EditText)findViewById(R.id.editText);
        String inputAuthor = editText2.getText().toString();

        //Set the title and author of the book and update it in the database
        course.setTitle(inputTitle);
        course.setProfessor(inputAuthor);
        tdb.updateCourse(course);

        //Go back to MainActivity
        setResult(RESULT_OK);
        finish();
    }

    //Called when the "DELETE" Button is clicked
    public void deleteData(View view){

        //Delete the selected book from the database and finish the activity
        tdb.deleteCourse(course);
        setResult(RESULT_OK);
        finish();

    }

}
