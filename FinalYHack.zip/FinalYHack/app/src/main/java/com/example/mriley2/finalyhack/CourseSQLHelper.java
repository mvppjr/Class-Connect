package com.example.mriley2.finalyhack;

import android.content.Context;
import android.content.ContentValues;
import android.database.SQLException;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.*;
import android.util.Log;


import java.util.ArrayList;
import java.util.List;

/**
 * Created by TMBL on 12/2/17.
 */

public class CourseSQLHelper extends SQLiteOpenHelper {
    static final String KEY_ROWID = "_id";
    static final String KEY_TITLE = "title";
    static final String KEY_PROFESSOR = "professor";
    static final String TAG = "CourseSQLHelper";
    static final String DATABASE_NAME = "MyDB";
    static final String DATABASE_TABLE = "courses";
    static final int DATABASE_VERSION = 1;
    static final String DATABASE_CREATE = "create table " + DATABASE_TABLE +
            " (" + KEY_ROWID + " integer primary key autoincrement, "
            + KEY_TITLE + " text not null, " + KEY_PROFESSOR + " text not null);";


    SQLiteDatabase db = getWritableDatabase();

    //Constructor
    CourseSQLHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //Initially creates a database if one does not exists
    @Override
    public void onCreate(SQLiteDatabase db0){
        try {
            //Create and get writable Database
            db0.execSQL(DATABASE_CREATE);
            //db = getWritableDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Updates the database from a previous version to a new version.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS "+ DATABASE_TABLE);
        onCreate(db);
    }


    //---add a Course object to the database---
    public void addCourse(Course course) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_TITLE, course.getTitle());
        initialValues.put(KEY_PROFESSOR, course.getProfessor());

        //Insert using the ContentValues
        long key0 = db.insert(DATABASE_TABLE, null, initialValues);
        int key1 = (int) key0;
        course.setID(key1);  //Sets the id of the Course object
    }

    //---deletes a particular Course object from the database by its rowID---
    public void deleteCourse(Course book) {
        db.delete(DATABASE_TABLE, KEY_ROWID + "=" + book.getID(), null);
    }

    //---updates a Book object in the database using its rowID---
    public void updateCourse(Course course) {
        ContentValues args = new ContentValues();
        args.put(KEY_TITLE, course.getTitle());
        args.put(KEY_PROFESSOR, course.getProfessor());
        //Update using the Content Values
        db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + course.getID(), null);
    }

    //---retrieves a particular Book object from the database using the id of the book---
    public Course searchCourse(int rowId) throws SQLException {
        Cursor mCursor = db.query(true, DATABASE_TABLE, new String[] {KEY_ROWID,
                        KEY_TITLE, KEY_PROFESSOR}, KEY_ROWID + "=" + rowId, null,
                null, null, null, null);
        //If book is found, create a new book object using the information and return it
        if (mCursor != null) {
            mCursor.moveToFirst();
            Course book = new Course(mCursor.getString(1), mCursor.getString(2));
            int id = Integer.parseInt(mCursor.getString(0));
            book.setID(id);
            return book;
        }
        return null; //If the book is not found
    }


    //---retrieves all the Book objects---
    public List<Course> getAllCourses() {
        Cursor mCursor = db.query(DATABASE_TABLE, new String[] {KEY_ROWID, KEY_TITLE,
                KEY_PROFESSOR}, null, null, null, null, null);

        List<Course> myList = new ArrayList<Course>();

        //Use the curser and loop through to add each book into the list
        if (mCursor.moveToFirst()) {
            do {
                Course course = new Course(mCursor.getString(1), mCursor.getString(2));
                int id = Integer.parseInt(mCursor.getString(0));
                course.setID(id);
                myList.add(course);
            }   while (mCursor.moveToNext());
        }
        return myList;
    }
}
