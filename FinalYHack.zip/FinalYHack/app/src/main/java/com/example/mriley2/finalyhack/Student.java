package com.example.mriley2.finalyhack;

import java.util.List;

/**
 * Created by TMBL on 12/2/17.
 */

public class Student {
    private int id;
    private String name;
    private String major;
    private String DOB;

    //Constructor
    public Student(String name0){
        name = name0;
    }

    //Returns the id of the book
    public int getID(){
        return id;
    }

    //Sets the id of the book
    public void setID(int id0){
        id = id0;
    }

    //Returns the title of the book
    public String getName(){
        return name;
    }

    //Sets the title of the book
    public void setName(String name0){
        name = name0;
    }

    //Returns the author of the book
    public String getMajor(){
        return major;
    }

    //Sets the author of the book
    public void setMajor(String major0){
        major = major0;
    }

    //Returns the author of the book
    public String getDOB(){
        return DOB;
    }

    //Sets the author of the book
    public void setDOB(String DOB0){
        DOB = DOB0;
    }

}
