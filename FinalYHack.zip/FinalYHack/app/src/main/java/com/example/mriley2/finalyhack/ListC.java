package com.example.mriley2.finalyhack;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class ListC extends ListActivity {

    //Instance variables
    List<Course> courselist;
    String[] titles =new String[] {};
    int request_Code = 1;
    CourseSQLHelper helper;

    //Creates the database, adds books and display the list of books
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Create and initialize the database
        helper = new CourseSQLHelper(this);
        helper.onUpgrade(helper.getWritableDatabase(), 1, 2);
        helper.getWritableDatabase();

        //Create course instances
        Course course1 = new Course(getString(R.string.course1), getString(R.string.professor1));
        Course course2 = new Course(getString(R.string.course2), getString(R.string.professor2));
        Course course3 = new Course(getString(R.string.course3), getString(R.string.professor3));
        Course course4 = new Course(getString(R.string.course4), getString(R.string.professor4));
        Course course5 = new Course(getString(R.string.course5), getString(R.string.professor5));
        Course course6 = new Course(getString(R.string.course6), getString(R.string.professor6));
        Course course7 = new Course(getString(R.string.course7), getString(R.string.professor7));
        Course course8 = new Course(getString(R.string.course8), getString(R.string.professor8));
        Course course9 = new Course(getString(R.string.course9), getString(R.string.professor9));

        //Insert courses into the database
        helper.addCourse(course1);
        helper.addCourse(course2);
        helper.addCourse(course3);
        helper.addCourse(course4);
        helper.addCourse(course5);
        helper.addCourse(course6);
        helper.addCourse(course7);
        helper.addCourse(course8);
        helper.addCourse(course9);

        //Get all the course from the database
        courselist = helper.getAllCourses();
        helper.close();

        //Retrieve the titles from the courselist
        int length = courselist.size();
        titles = new String[length];
        for (int i=0; i<length; i++){
            titles[i] = courselist.get(i).getTitle();
        }

        //Set up the listview and display it
        setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, titles));
    }

    //Creates an options menu at the action bar of the mainactivity.
    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        MenuItem item1 = menu.add(0,0,0,"Add New Course");
        item1.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    //When the options menu is selected, creates a new activity to add a book
    //@Override
    //public boolean onOptionsItemSelected(MenuItem item){
    //    Intent intent = new Intent(this, NewBookActivity.class);
    //    startActivityForResult(intent, request_Code);
    //    return true;
    //}

    //When any of the book titles is clicked on the Listview
    @Override
    public void onListItemClick(ListView parent, View v, int position, long id){
        super.onListItemClick(parent, v, position, id);
        Intent intent = new Intent(this, CourseActivity.class);
        int ID = courselist.get(position).getID();
        intent.putExtra("id", ID);
        startActivityForResult(intent, request_Code);
    }

    //This method is called when we close an activity to go back to the MainActivity
    // and refresh the list of titles.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent){
        super.onActivityResult(requestCode, resultCode, intent);
        //refresh list of books here
        if (requestCode == request_Code) {
            if (resultCode == RESULT_OK){
                helper = new CourseSQLHelper(this);
                helper.getWritableDatabase();

                courselist = helper.getAllCourses();
                helper.close();

                //Retrieve the titles from the booklist
                int length = courselist.size();
                titles = new String[length];
                for (int i=0; i<length; i++){
                    titles[i] = courselist.get(i).getTitle();
                }

                //Set up the listview
                setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, titles));

            }
        }
    }
}
